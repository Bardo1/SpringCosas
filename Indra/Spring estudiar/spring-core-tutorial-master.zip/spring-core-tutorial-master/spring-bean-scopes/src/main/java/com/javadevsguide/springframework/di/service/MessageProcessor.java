package com.javadevsguide.springframework.di.service;

public interface MessageProcessor {
	public void processMsg(String message);
}
