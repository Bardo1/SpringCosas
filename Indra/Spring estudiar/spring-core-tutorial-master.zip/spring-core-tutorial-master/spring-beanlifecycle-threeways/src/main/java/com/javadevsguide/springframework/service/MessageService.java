package com.javadevsguide.springframework.service;

public interface MessageService {
	public void sendMsg(String message);
}
