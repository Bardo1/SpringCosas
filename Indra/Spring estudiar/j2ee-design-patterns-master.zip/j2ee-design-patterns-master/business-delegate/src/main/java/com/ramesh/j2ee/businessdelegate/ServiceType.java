package com.ramesh.j2ee.businessdelegate;

/**
 * 
 * Enumeration for service types
 * @author RAMESH
 *
 */
public enum ServiceType {

  EJB, JMS,EMAIL;
}
