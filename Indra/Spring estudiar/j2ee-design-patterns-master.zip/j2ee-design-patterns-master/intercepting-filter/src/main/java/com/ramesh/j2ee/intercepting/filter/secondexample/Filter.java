package com.ramesh.j2ee.intercepting.filter.secondexample;

public interface Filter {
	public void execute(String request);
}
