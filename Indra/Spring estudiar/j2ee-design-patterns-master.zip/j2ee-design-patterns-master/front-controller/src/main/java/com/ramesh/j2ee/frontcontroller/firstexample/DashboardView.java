package com.ramesh.j2ee.frontcontroller.firstexample;

public class DashboardView {
	public void show() {
		System.out.println("Displaying Dashboad Page");
	}
}