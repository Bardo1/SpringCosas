package com.ramesh.j2ee.frontcontroller.firstexample;

public class StudentView {
	   public void show(){
	      System.out.println("Displaying Student Page");
	   }
	}
