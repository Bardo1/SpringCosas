package com.ramesh.j2ee.frontcontroller.firstexample;

public class ErrorView {
	   public void show(){
	      System.out.println("Displaying Error Page");
	   }
	}
