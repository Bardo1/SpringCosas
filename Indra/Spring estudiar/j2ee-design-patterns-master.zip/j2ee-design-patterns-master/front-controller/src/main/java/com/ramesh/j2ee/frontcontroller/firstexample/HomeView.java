package com.ramesh.j2ee.frontcontroller.firstexample;

public class HomeView {
	public void show() {
		System.out.println("Displaying Home Page");
	}
}
