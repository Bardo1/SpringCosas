package com.ramesh.dependencyinjection;

public class MSServerConnection {

}
