package com.developersguide.junit;

public class types {

}
