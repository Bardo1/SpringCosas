<div dir="ltr" style="text-align: left;" trbidi="on">
<div class="separator" style="clear: both; text-align: center;">
<a href="https://1.bp.blogspot.com/-42eaaDLkSfo/Wzj2FZrc1BI/AAAAAAAACqU/qTcRUiiwCtgN4zKU6T-bH1rnmy-xfW_0QCLcBGAs/s1600/junit-logo.png" imageanchor="1" style="margin-left: 1em; margin-right: 1em;"><span style="font-family: &quot;verdana&quot; , sans-serif;"><img border="0" data-original-height="64" data-original-width="160" height="160" src="https://1.bp.blogspot.com/-42eaaDLkSfo/Wzj2FZrc1BI/AAAAAAAACqU/qTcRUiiwCtgN4zKU6T-bH1rnmy-xfW_0QCLcBGAs/s400/junit-logo.png" width="400"></span></a></div>
<b style="background-color: white; font-size: 16px;"><span style="font-family: &quot;verdana&quot; , sans-serif;">1. JUnit 4 Developer Guide</span></b><br>
<ul style="text-align: left;">
<li><a href="http://www.javaguides.net/2018/07/introduction-to-junit-framework.html" target="_blank"><span style="font-family: &quot;verdana&quot; , sans-serif;">Introduction to JUnit Framework</span></a></li>
<li><a href="http://www.javaguides.net/2018/07/junit-getting-started-guide.html" target="_blank"><span style="font-family: &quot;verdana&quot; , sans-serif;">JUnit Getting Started Guide</span></a></li>
<li><span style="font-family: &quot;verdana&quot; , sans-serif;"><a href="http://www.javaguides.net/2018/07/junit-4-simple-basic-template.html" target="_blank">JUnit 4 Simple Basic Template</a></span></li>
<li><a href="http://www.javaguides.net/2018/07/junit-4-annotations-with-examples.html" target="_blank"><span style="font-family: &quot;verdana&quot; , sans-serif;">JUnit 4 Annotations with Examples</span></a></li>
<li><a href="http://www.javaguides.net/2018/07/junit-4-assertions-with-examples1.html" target="_blank"><span style="font-family: &quot;verdana&quot; , sans-serif;">JUnit 4 Assertions with Examples</span></a></li>
<li><a href="http://www.javaguides.net/2018/07/guide-to-junit-4-assertions.html" target="_blank"><span style="font-family: &quot;verdana&quot; , sans-serif;">Guide to JUnit 4 Assertions</span></a></li>
<li><a href="http://www.javaguides.net/2018/07/junit-4-test-execution-order-example.html" target="_blank"><span style="font-family: &quot;verdana&quot; , sans-serif;">JUnit 4 Test Execution Order Example</span></a></li>
<li><a href="http://www.javaguides.net/2018/07/junit-4-test-fixtures-examples.html" target="_blank"><span style="font-family: &quot;verdana&quot; , sans-serif;">JUnit 4 Test Fixtures Examples</span></a></li>
<li><a href="http://www.javaguides.net/2018/07/how-to-ignore-tests-in-junit-4.html" target="_blank"><span style="font-family: &quot;verdana&quot; , sans-serif;">How to Ignore Tests in Junit 4</span></a></li>
<li><a href="http://www.javaguides.net/2018/07/junit-4-aggregating-tests-in-suites.html" target="_blank"><span style="font-family: &quot;verdana&quot; , sans-serif;">JUnit 4 Aggregating Tests in Suites</span></a></li>
<li><span style="font-family: &quot;verdana&quot; , sans-serif;"><a href="http://www.javaguides.net/2018/07/junit-4-exception-testing-example.html" target="_blank">JUnit 4 Exception Testing Example</a></span></li>
<li><a href="http://www.javaguides.net/2018/07/junit-4-timeout-for-tests-example.html" target="_blank"><span style="font-family: &quot;verdana&quot; , sans-serif;">JUnit 4 Timeout for Tests Example</span></a></li>
<li><a href="http://www.javaguides.net/2018/07/junit-4-parameterized-tests.html" target="_blank"><span style="font-family: &quot;verdana&quot; , sans-serif;">JUnit 4 Parameterized Tests</span></a></li>
<li><a href="http://www.javaguides.net/2018/07/junit-4-categories-example.html" target="_blank"><span style="font-family: &quot;verdana&quot; , sans-serif;">JUnit 4 Categories Example</span></a></li>
</ul>
<div>
<span style="font-family: &quot;verdana&quot; , sans-serif;"><span style="background-color: white; font-size: 16px;"><b>2. GitHub Repository</b></span></span><br>
<ul style="background-color: white; font-size: 16px;">
<li><a href="https://github.com/RameshMF/junit-developer-guide" style="background: transparent; color: #0064c1; text-decoration-line: none;" target="_blank"><span style="font-family: &quot;verdana&quot; , sans-serif;">JUnit 4 Developer Guide</span></a></li>
</ul>
<span style="font-family: &quot;verdana&quot; , sans-serif;"><b style="background-color: white; font-size: 16px;">3. Important Java Developer Guides</b></span><br>
<div style="background-color: white; font-size: 16px;">
</div>
<ul style="background-color: white; font-size: 16px;">
<li><a href="http://www.javaguides.net/search/label/Java%20Best%20Practices" style="background: transparent; color: #0064c1; text-decoration-line: none;" target="_blank"><span style="font-family: &quot;verdana&quot; , sans-serif;">Java/J2EE Best Practices</span></a></li>
<li><a href="http://www.javaguides.net/p/jersey-rest.html" style="background: transparent; color: #0064c1; text-decoration-line: none;" target="_blank"><span style="font-family: &quot;verdana&quot; , sans-serif;">Jersey Rest Developer Guide</span></a></li>
<li><a href="http://www.javaguides.net/p/core-java.html" style="background: transparent; color: #0064c1; text-decoration-line: none;" target="_blank"><span style="font-family: &quot;verdana&quot; , sans-serif;">Core Java Developer Guide</span></a></li>
<li><a href="http://www.javaguides.net/p/java-8.html" style="background: transparent; color: #0064c1; text-decoration-line: none;" target="_blank"><span style="font-family: &quot;verdana&quot; , sans-serif;">Java 8 Developer Guide</span></a></li>
<li><a href="http://www.javaguides.net/p/spring-framework.html" style="background: transparent; color: #0064c1; text-decoration-line: none;" target="_blank"><span style="font-family: &quot;verdana&quot; , sans-serif;">Spring Developer Guide</span></a></li>
<li><span style="background: transparent; color: #0064c1; font-family: &quot;verdana&quot; , sans-serif;"><a href="http://www.javaguides.net/p/maven.html" style="background: transparent; color: #0064c1; text-decoration-line: none;" target="_blank">Maven developers Guide</a></span></li>
<li><a href="http://www.javaguides.net/p/junit-5.html" target="_blank"><span style="font-family: &quot;verdana&quot; , sans-serif;">JUnit 5 Developers Guide</span></a></li>
</ul>
</div>
<div>
<br></div>
</div>
