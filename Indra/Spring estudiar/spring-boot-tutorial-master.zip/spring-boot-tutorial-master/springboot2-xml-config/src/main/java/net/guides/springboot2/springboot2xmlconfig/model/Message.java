package net.guides.springboot2.springboot2xmlconfig.model;

public class Message {
	private int id;
	private String message;
	public Message(int id, String message) {
		super();
		this.id = id;
		this.message = message;
	}
}
