<div dir="ltr" style="text-align: left;" trbidi="on">
<h2 style="text-align: left;">
Java Best Practices</h2>
<div>
<div style="text-align: left;">
</div>
<ul style="text-align: left;">
<li><a href="http://www.javaguides.net/2018/06/guide-to-java-exception-handling-best-practices.html" target="_blank">Java Exception Handling Best Practices</a></li>
</ul>
<ul style="text-align: left;">
<li><a href="http://www.javaguides.net/2018/06/java-synchronization-best-practices.html" target="_blank">Java Synchronization Best Practices</a></li>
</ul>
<ul style="text-align: left;">
<li><a href="http://www.javaguides.net/2018/06/guide-to-string-best-practices-in-java.html" target="_blank">String Best Practices in Java</a></li>
</ul>
<ul style="text-align: left;">
<li><a href="http://www.javaguides.net/2018/06/guide-to-best-practices-to-java.html" target="_blank">Best Practices to Java Collection Framework</a></li>
</ul>
<ul style="text-align: left;">
<li><a href="http://www.javaguides.net/2018/07/secure-coding-standards-for-java-serialization7.html" target="_blank">Secure Coding Standards for Java Serialization</a></li>
</ul>
</div>
<div>
<h2>
J2EE Best Practices</h2>
</div>
<div>
<div>
<div style="text-align: left;">
</div>
<ul style="text-align: left;">
<li><a href="http://www.javaguides.net/2018/06/guide-to-jdbc-best-practices.html" target="_blank">JDBC Best Practices</a></li>
</ul>
<ul style="text-align: left;">
<li><a href="http://www.javaguides.net/2018/06/jsp-best-practices.html" target="_blank">JSP Best Practices</a></li>
</ul>
<ul style="text-align: left;">
<li><a href="http://www.javaguides.net/2018/06/restful-api-design-best-practices.html" target="_blank">Restful API Design Best Practices</a></li>
</ul>
</div>
</div>
</div>
