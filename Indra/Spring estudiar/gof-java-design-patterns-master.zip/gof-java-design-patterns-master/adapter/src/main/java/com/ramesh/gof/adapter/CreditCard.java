package com.ramesh.gof.adapter;

public interface CreditCard {
	public void giveBankDetails();

	public String getCreditCard();
}// End of the CreditCard interface.
