package com.ramesh.gof.proxy;

/**
 * 
 * Batch interface.
 *
 */
public interface Batch {

	int totalStudents();

	void registerStudent(String name);
}
