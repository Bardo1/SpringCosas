package com.ramesh.gof.decorator.headfirst;

public abstract class CondimentDecorator extends Beverage {
	public abstract String getDescription();
}
