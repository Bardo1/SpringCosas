package com.ramesh.gof.factory.pizzaa;

public class Garlic implements Veggies {

	public String toString() {
		return "Garlic";
	}
}
