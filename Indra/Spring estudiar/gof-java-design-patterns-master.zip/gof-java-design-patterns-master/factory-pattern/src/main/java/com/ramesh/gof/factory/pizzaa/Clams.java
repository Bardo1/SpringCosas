package com.ramesh.gof.factory.pizzaa;

public interface Clams {
	public String toString();
}
