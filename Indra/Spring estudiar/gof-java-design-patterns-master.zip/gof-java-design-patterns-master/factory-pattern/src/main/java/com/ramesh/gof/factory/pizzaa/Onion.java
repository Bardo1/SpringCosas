package com.ramesh.gof.factory.pizzaa;

public class Onion implements Veggies {

	public String toString() {
		return "Onion";
	}
}
