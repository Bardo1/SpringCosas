package com.ramesh.gof.factory.pizzaa;

public interface Veggies {
	public String toString();
}
