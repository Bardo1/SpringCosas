package com.ramesh.gof.factory.pizzaa;

public interface Pepperoni {
	public String toString();
}
