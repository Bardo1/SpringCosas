package com.ramesh.gof.factory.pizzaa;

public class BlackOlives implements Veggies {

	public String toString() {
		return "Black Olives";
	}
}
