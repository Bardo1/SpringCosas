package com.ramesh.gof.factory.pizzaa;

public class Mushroom implements Veggies {

	public String toString() {
		return "Mushrooms";
	}
}
