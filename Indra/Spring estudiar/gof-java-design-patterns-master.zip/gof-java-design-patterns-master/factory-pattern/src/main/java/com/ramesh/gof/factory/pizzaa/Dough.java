package com.ramesh.gof.factory.pizzaa;

public interface Dough {
	public String toString();
}
