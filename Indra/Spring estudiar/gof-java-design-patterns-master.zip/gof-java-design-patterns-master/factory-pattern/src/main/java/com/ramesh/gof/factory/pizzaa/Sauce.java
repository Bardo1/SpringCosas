package com.ramesh.gof.factory.pizzaa;

public interface Sauce {
	public String toString();
}
