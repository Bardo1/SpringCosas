package com.ramesh.gof.state.firstexample;

public interface State {
	public void doAction(Context context);
}
