package com.ramesh.gof.state.secondexample;

public interface State {
	 public void doAction();
	}
