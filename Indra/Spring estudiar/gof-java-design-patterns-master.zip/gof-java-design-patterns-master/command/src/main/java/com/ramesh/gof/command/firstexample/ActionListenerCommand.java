package com.ramesh.gof.command.firstexample;

public interface ActionListenerCommand {
	
	public void execute();

}
